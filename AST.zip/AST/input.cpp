int main(){
	
	int i, a, b;
	int nume=3.45;	
	for(i = 0;  i < 10; i++){
		// for(a = 1; a <= 20; a = a+2){
			b = 25 + i;
		// }
	}
	i=1;
	while(i<5)
	{
		a=b+1;
	}
	if(i>1)
		a=b+1;
}
