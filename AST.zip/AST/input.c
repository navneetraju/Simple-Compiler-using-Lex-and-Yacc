
int main(){
	
	int i, a, b;
	int nume=3.45;	
	
	if(i<5){
	a=a+5;
	}
	

	a = 3*2+5/4-9;

}
